#define PATTERNS_CURRENT_TEXTLIMIT 1000
#define PATTERNS_NAME_TEXTLIMIT 512
#define PATTERNS_SEQUENCE_TEXTLIMIT 3
#define PATTERNS_TITLE "Pattern Editor"

class PATTERNS
{
public:
	PATTERNS();
	void init();
	void free();
	void reset();
	void update();
	void quit();

	HWND hwndPatternEditor;
	WORD IDD_PATTERN_EDITOR;

	std::vector<std::string> autofire_patterns_names;
	std::vector<std::vector<uint8>> autofire_patterns;

	void InitPatterns();
	void UpdateEnabledItems();
	bool SavePattern();
	int MakePattern(std::string tmpstr1, std::string tmpstr2);
	int MakeSequencePattern(int on, int off);
	bool LoadPatterns();
	void DefaultPatterns();
	void ResetPattern();
	void DeletePattern();
	void CheckTypeOf();

	bool InputColumnSetPattern(int joy, int button);
	void InputSetPattern(int start, int end, int joy, int button, int consecutive_tag);
	bool FrameColumnSetPattern();

//	void UpdatePatternsMenu();
//	void RecheckPatternsMenu();

	bool must_update, isChanged, model, sequentially;

private:
	bool ReadString(EMUFILE *is, std::string& dest);
	std::string FixLength(std::string str);
//	LPSTR PatternToString(std::vector<u8,std::allocator<u8>> pat);
	std::string PatternToString(std::vector<u8,std::allocator<u8>> pat);

	int sequence_on, sequence_off;
//	bool model, sequentially;
	std::string pattern_name, fixed_pattern;

	HWND hwndPatternName, hwndCurrentPattern, hwndSequenceON, hwndSequenceOFF;
//	HWND hwndSetPattern;
};