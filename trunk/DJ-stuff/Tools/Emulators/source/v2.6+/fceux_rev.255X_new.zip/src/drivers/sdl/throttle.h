void RefreshThrottleFPS(void);
int SpeedThrottle(void);
