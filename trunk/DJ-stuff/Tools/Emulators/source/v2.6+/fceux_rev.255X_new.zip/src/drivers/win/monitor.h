void DoByteMonitor();
