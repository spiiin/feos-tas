void InitSpeedThrottle(void);
int SpeedThrottle(void);
void RefreshThrottleFPS();
