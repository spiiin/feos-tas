void SaveConfig(const char *filename);
void LoadConfig(const char *filename);

extern int InputType[3];
