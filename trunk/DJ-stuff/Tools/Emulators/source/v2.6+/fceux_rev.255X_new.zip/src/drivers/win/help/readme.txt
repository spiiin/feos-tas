Source project (HelpNDoc3 file) to compile this chm is there:
\fceux\fceu\vc\Help\fceux.hnd
