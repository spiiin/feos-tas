bool CreateSoundSave();
int CloseWave();
