// Specification file for SPLICER class

class SPLICER
{
public:
	SPLICER();
	void init();
	void reset();
	void update();

	void CloneFrames();
	void InsertFrames();
	void InsertNumFrames();
	void DeleteFrames();
	void ClearFrames(SelectionFrames* current_selection = 0);
	void Truncate();
	bool Copy(SelectionFrames* current_selection = 0);
	void Cut();
	bool Paste();
	bool PasteInsert();

	void RandomInput(int joy);
	void DeleteInputs(int joy);
	void InsertInputs(int joy);
	void InvertInput(int joy);		
	void ClearInput(int joy);
	void ClearSequence(int joy, int whenever, int amount);
	void SwapUpDown(int joy);
	void SwapLeftRight(int joy);
	void SwapJoys(int joysrc, int joydesc);
	void MoveJoys(int joysrc, int joydesc);
	void CloneJoys(int joysrc, int joydesc);

	void RedrawTextClipboard();

	SelectionFrames& GetClipboardSelection();

	bool must_redraw_selection_text;

private:
	void CheckClipboard();

	SelectionFrames clipboard_selection;
	HWND hwndTextSelection, hwndTextClipboard;

};
