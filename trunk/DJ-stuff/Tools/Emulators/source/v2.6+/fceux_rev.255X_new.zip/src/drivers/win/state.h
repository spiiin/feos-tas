void FCEUD_SaveStateAs();
void FCEUD_LoadStateFrom();

void LoadBackup();					//Load backup savestate
