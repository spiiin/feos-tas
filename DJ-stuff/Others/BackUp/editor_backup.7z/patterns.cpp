/* ---------------------------------------------------------------------------------
Implementation file of PATTERNS class
Copyright (c) 2012-2013 TheZlomuS

(The MIT License)
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
------------------------------------------------------------------------------------
Pattern - Pattern settings/options
[Singleton]

* stores current pattern of TAS Editor to "taseditor_patterns.txt"
* control user selection at any moment
* TAS Editor load patterns of "taseditor_patterns.txt"
* ???
------------------------------------------------------------------------------------ */

//#include "../common.h"
//#include "patterns.h"
#include "taseditor_project.h"
//#include "../../../fceu.h"
//#include "taseditor_window.h"

//extern void SetAutoFirePattern(int onframes, int offframes);

extern TASEDITOR_WINDOW taseditor_window;
extern TASEDITOR_CONFIG taseditor_config;

extern PATTERNS patterns;
extern HISTORY history;
extern MARKERS_MANAGER markers_manager;
extern PLAYBACK playback;
extern GREENZONE greenzone;
extern PIANO_ROLL piano_roll;
extern SELECTION selection;

extern int joysticks_per_frame[NUM_SUPPORTED_INPUT_TYPES];
extern int GetInputType(MovieData& md);

// main window wndproc
BOOL CALLBACK PatternEditorProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK PatternManagerProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

// resources
char patternsFilename[] = "\\taseditor_patterns.txt";
char autofire_patterns_flagpress = 49;	//	"1"

PATTERNS::PATTERNS()
{
	hwndPatternEditor = 0;
	hwndPatternName = 0;
	hwndCurrentPattern = 0;
//	hwndSetPattern = 0;
	DefaultSettings();
}

//IDC_PATTERNS_OFF - val
//IDC_PATTERNS_CURRENT - text
//IDC_PATTERNS_SEQUENCE - radio
//IDC_PATTERNS_FORMULA - radio
//IDC_PATTERNS_ON - val
//IDC_PATTERNS_NAME - text
//ID_PATTERNS_DEFAULT - button
//ID_PATTERNS_RESET - button
//IDC_PATTERNS_SETPATTERN - combo


void PATTERNS::init()
{
	free();

//	initialize componetsDialogBox
	hwndPatternManager = CreateDialog(fceu_hInstance, "PATTERNMANAGER", hAppWnd, PatternManagerProc);
	hwndPatternEditor = CreateDialog(fceu_hInstance, MAKEINTRESOURCE(IDD_TASEDITOR_PATTERNEDITOR), hwndPatternManager, PatternEditorProc);
	
	hwndPatternName = GetDlgItem(hwndPatternEditor, IDC_PATTERNS_NAME);
	hwndCurrentPattern = GetDlgItem(hwndPatternEditor, IDC_PATTERNS_CURRENT);
	hwndSequenceON = GetDlgItem(hwndPatternEditor, IDC_PATTERNS_ON);
	hwndSequenceOFF = GetDlgItem(hwndPatternEditor, IDC_PATTERNS_OFF);
	hwndIncreaseBy = GetDlgItem(hwndPatternEditor, IDC_PATTERNS_INCBY);
	hwndMaxSize = GetDlgItem(hwndPatternEditor, IDC_PATTERNS_MAXSIZE);
	
	hwndSelectPattern = GetDlgItem(hwndPatternManager, IDC_PATTERNS_SELECTPATTERN);

	Reinitialization();

	UpdateManager();
	//this will superseded by combobox
//	if (taseditor_config.current_pattern < 0 && taseditor_config.current_pattern >= autofire_patterns.size() && autofire_patterns_names.at(taseditor_config.current_pattern).size() <= 0 && autofire_pa)
//	{
//	}
//	Bug maker!
//	else
//	{
//		pattern_name = FixLength(autofire_patterns_names.at(taseditor_config.current_pattern));
//		fixed_pattern = FixLength(PatternToString(autofire_patterns.at(taseditor_config.current_pattern)));
//
//	}

	reset();
}

void PATTERNS::free()
{
	InitPatterns();
}

bool AskSavePatterns()
{
	if (patterns.isChanged)
	{
		int answer = MessageBox(patterns.hwndPatternEditor, "Save Pattern changes?", PATTERNS_EDITORTITLE, MB_YESNO); //MB_YESNOCANCEL);
		if (answer == IDYES)
			return patterns.SavePatterns();
//		return (answer != IDCANCEL);
	}
	patterns.isChanged = false;
	return true;
}

void PATTERNS::quit()
{
	AskSavePatterns();

	if (hwndPatternEditor)
	{
		DestroyWindow(hwndPatternEditor);
		hwndPatternEditor = 0;
	}
	if (hwndPatternManager)
	{
		DestroyWindow(hwndPatternManager);
		hwndPatternManager = 0;
	}
	if (hwndPatternName)
	{
		DestroyWindow(hwndPatternName);
		hwndPatternName = 0;
	}
	if (hwndCurrentPattern)
	{
		DestroyWindow(hwndCurrentPattern);
		hwndCurrentPattern = 0;
	}
	if (hwndSelectPattern)
	{
		DestroyWindow(hwndSelectPattern);
		hwndSelectPattern = 0;
	}
	if (hwndSequenceOFF)
	{
		DestroyWindow(hwndSequenceOFF);
		hwndSequenceOFF = 0;
	}
	if (hwndSequenceON)
	{
		DestroyWindow(hwndSequenceON);
		hwndSequenceON = 0;
	}
	if (hwndMaxSize)
	{	
		DestroyWindow(hwndMaxSize);
		hwndMaxSize = 0;
	}
	if (hwndIncreaseBy)
	{
		DestroyWindow(hwndIncreaseBy);
		hwndIncreaseBy = 0;
	}
}

void PATTERNS::reset()
{
	must_update = true;
	update();
}

void PATTERNS::Reinitialization()
{
	SetDlgItemInt(hwndPatternEditor,IDC_PATTERNS_ON,sequence_on,0);
	SetDlgItemInt(hwndPatternEditor,IDC_PATTERNS_OFF,sequence_off,0);
	SetDlgItemInt(hwndPatternEditor,IDC_PATTERNS_INCBY,increase_by,0);
	SetDlgItemInt(hwndPatternEditor,IDC_PATTERNS_MAXSIZE,max_size,0);

	SetDlgItemText(hwndPatternEditor,IDC_PATTERNS_NAME,(LPSTR)pattern_name.c_str());
	SetDlgItemText(hwndPatternEditor,IDC_PATTERNS_CURRENT,(LPSTR)fixed_pattern.c_str());

	SendDlgItemMessage(hwndPatternEditor,IDC_PATTERNS_NAME,EM_SETLIMITTEXT,PATTERNS_NAME_TEXTLIMIT,0);
	SendDlgItemMessage(hwndPatternEditor,IDC_PATTERNS_CURRENT,EM_SETLIMITTEXT,PATTERNS_CURRENT_TEXTLIMIT,0);
	SendDlgItemMessage(hwndPatternEditor,IDC_PATTERNS_ON,EM_SETLIMITTEXT,PATTERNS_MAXINT_TEXTLIMIT,0);
	SendDlgItemMessage(hwndPatternEditor,IDC_PATTERNS_OFF,EM_SETLIMITTEXT,PATTERNS_MAXINT_TEXTLIMIT,0);
	SendDlgItemMessage(hwndPatternEditor,IDC_PATTERNS_INCBY,EM_SETLIMITTEXT,PATTERNS_MAXINT_TEXTLIMIT,0);
	SendDlgItemMessage(hwndPatternEditor,IDC_PATTERNS_MAXSIZE,EM_SETLIMITTEXT,PATTERNS_MAXINT_TEXTLIMIT,0);
}

void PATTERNS::DefaultSettings()
{
	sequence_on = 1;
	sequence_off = 1;
	increase_by = 1;
	max_size = 6;
	sequentially = true;
	patOper = MAKE_NEW;
//	pattern_name = new char[PATTERNS_NAME_TEXTLIMIT];
//	fixed_pattern = new char[PATTERNS_CURRENT_TEXTLIMIT];
	isChanged = false;
	pattern_name = "New Pattern";
	fixed_pattern = "10";
}

void PATTERNS::UpdateEnabledItems()
{
	if(sequentially)
	{
		EnableWindow(hwndSequenceON, 1);
		EnableWindow(hwndSequenceOFF, 1);
		EnableWindow(hwndPatternName, 0);
		EnableWindow(hwndCurrentPattern, 0);
		EnableWindow(hwndIncreaseBy, 0);
		EnableWindow(hwndMaxSize, 0);
	}
	else if (iteratively)
	{
		EnableWindow(hwndSequenceON, 0);
		EnableWindow(hwndSequenceOFF, 0);
		EnableWindow(hwndPatternName, 0);
		EnableWindow(hwndCurrentPattern, 0);
		EnableWindow(hwndIncreaseBy, 1);
		EnableWindow(hwndMaxSize, 1);
	}
	else
	{
		EnableWindow(hwndSequenceON, 0);
		EnableWindow(hwndSequenceOFF, 0);
		EnableWindow(hwndPatternName, 1);
		EnableWindow(hwndCurrentPattern, 1);
		EnableWindow(hwndIncreaseBy, 0);
		EnableWindow(hwndMaxSize, 0);
	}
}

void PATTERNS::InitPatterns()
{
	autofire_patterns.resize(0);
	autofire_patterns_names.resize(0);

	LoadPatterns();
}

bool AskDefaultPatterns()
{
	if (MessageBox(patterns.hwndPatternEditor, "Do you really want to set default patterns?", PATTERNS_MANAGERTITLE, MB_YESNOCANCEL) == IDYES)
		return true;
	else return false;
}

void ExitPatternEditor()
{
//	if (!AskSavePatterns()) return;
	
	if (ShowWindow(patterns.hwndPatternEditor, SW_HIDE))
		EnableWindow(patterns.hwndPatternManager, true);
//	patterns.quit();
}

bool PATTERNS::SavePatterns()
{
	//this should modify "taseditor_patterns.txt" file
	std::string tempstr;

	for(int i = 0; i < autofire_patterns.size(); i++)
	{
		tempstr += autofire_patterns_names[i] + PATTERNS_ENTERSTR;
		tempstr += PatternToString(autofire_patterns[i]) + PATTERNS_ENTERSTR;
	}

	char nameo[2048];
	strncpy(nameo, FCEU_GetPath(FCEUMKF_TASEDITOR).c_str(), 2047);
	strncat(nameo, patternsFilename, 2047 - strlen(nameo));
	EMUFILE_FILE ifs(nameo, "wb");
	if (!ifs.fail())
	{
		(tempstr += PATTERNS_ENTERSTR) += PATTERNS_ADDFORMATINFO;
		ifs.fprintf(tempstr.c_str());
		MessageBox(hwndPatternEditor, "Patterns succesfuly saved!", PATTERNS_MANAGERTITLE, MB_ICONINFORMATION | MB_OK);
		isChanged = false;
	}
	else 
	{
		MessageBox(hwndPatternEditor, "Cannot save patterns!\nMaybe files is protected or disk don't have enough space to do it.", PATTERNS_MANAGERTITLE, MB_ICONERROR | MB_OK);
		return false;
	}

	return true;
}

bool PATTERNS::InputColumnSetPattern(int joy, int button)
{
	if (joy < 0 || joy >= joysticks_per_frame[GetInputType(currMovieData)]) return false;

	SelectionFrames* current_selection = selection.MakeStrobe();
	if (current_selection->size() == 0) return false;
	SelectionFrames::iterator current_selection_begin(current_selection->begin());
	SelectionFrames::iterator current_selection_end(current_selection->end());
	int pattern_offset = 0, current_pattern = taseditor_config.current_pattern;

	for(SelectionFrames::iterator it(current_selection_begin); it != current_selection_end; it++)
	{
		// skip lag frames
		if (taseditor_config.pattern_skips_lag && greenzone.laglog.GetLagInfoAtFrame(*it) == LAGGED_YES)
			continue;
		currMovieData.records[*it].setBitValue(joy, button, autofire_patterns[current_pattern][pattern_offset] != 0);
		pattern_offset++;
		if (pattern_offset >= (int)autofire_patterns[current_pattern].size())
			pattern_offset -= autofire_patterns[current_pattern].size();
	}
	int first_changes = history.RegisterChanges(MODTYPE_PATTERN, *current_selection_begin, *current_selection->rbegin(), 0, autofire_patterns_names[current_pattern].c_str());
	if (first_changes >= 0)
	{
		greenzone.InvalidateAndCheck(first_changes);
		return true;
	} else
		return false;
}

void PATTERNS::InputSetPattern(int start, int end, int joy, int button, int consecutive_tag)
{
	if (joy < 0 || joy >= joysticks_per_frame[GetInputType(currMovieData)]) return;

	if (start > end)
	{
		// swap
		int temp_start = start;
		start = end;
		end = temp_start;
	}
	if (start < 0) start = end;
	if (end >= currMovieData.getNumRecords())
		return;

	int pattern_offset = 0, current_pattern = taseditor_config.current_pattern;
	bool changes_made = false;
	bool value;

	for (int i = start; i <= end; ++i)
	{
		// skip lag frames
		if (taseditor_config.pattern_skips_lag && greenzone.laglog.GetLagInfoAtFrame(i) == LAGGED_YES)
			continue;
		value = (autofire_patterns[current_pattern][pattern_offset] != 0);
		if (currMovieData.records[i].checkBit(joy, button) != value)
		{
			changes_made = true;
			currMovieData.records[i].setBitValue(joy, button, value);
		}
		pattern_offset++;
		if (pattern_offset >= (int)autofire_patterns[current_pattern].size())
			pattern_offset -= autofire_patterns[current_pattern].size();
	}
	if (changes_made)
		greenzone.InvalidateAndCheck(history.RegisterChanges(MODTYPE_PATTERN, start, end, 0, autofire_patterns_names[current_pattern].c_str(), consecutive_tag));
}

bool PATTERNS::FrameColumnSetPattern()
{
	SelectionFrames* current_selection = selection.MakeStrobe();
	if (current_selection->size() == 0) return false;
	SelectionFrames::iterator current_selection_begin(current_selection->begin());
	SelectionFrames::iterator current_selection_end(current_selection->end());
	int pattern_offset = 0, current_pattern = taseditor_config.current_pattern;
	bool changes_made = false;

	for(SelectionFrames::iterator it(current_selection_begin); it != current_selection_end; it++)
	{
		// skip lag frames
		if (taseditor_config.pattern_skips_lag && greenzone.laglog.GetLagInfoAtFrame(*it) == LAGGED_YES)
			continue;
		if (autofire_patterns[current_pattern][pattern_offset])
		{
			if (!markers_manager.GetMarker(*it))
			{
				if (markers_manager.SetMarker(*it))
				{
					changes_made = true;
					piano_roll.RedrawRow(*it);
				}
			}
		} else
		{
			if (markers_manager.GetMarker(*it))
			{
				markers_manager.ClearMarker(*it);
				changes_made = true;
				piano_roll.RedrawRow(*it);
			}
		}
		pattern_offset++;
		if (pattern_offset >= (int)autofire_patterns[current_pattern].size())
			pattern_offset -= autofire_patterns[current_pattern].size();
	}
	if (changes_made)
	{
		history.RegisterMarkersChange(MODTYPE_MARKER_PATTERN, *current_selection_begin, *current_selection->rbegin(), autofire_patterns_names[current_pattern].c_str());
		selection.must_find_current_marker = playback.must_find_current_marker = true;
		return true;
	} else
		return false;
}

//LPSTR PATTERNS::PatternToString(std::vector<u8, std::allocator<u8>> pat)
std::string PATTERNS::PatternToString(std::vector<u8, std::allocator<u8>> pat)
{
	std::string temp_str = "";
	
	for (int i = 0; i < pat.size(); i++)
		temp_str += (char)(pat[i] + 0x30);

	return temp_str;
}

int PATTERNS::MakePattern(std::string tmpstr1, std::string tmpstr2)
{
	int total_pattrns = autofire_patterns.size();
	total_pattrns++;
	// save the name
	autofire_patterns_names.push_back(tmpstr1);
	// parse 2nd string to sequence of 1s and 0s
	autofire_patterns.resize(total_pattrns);
	ChangePattern(tmpstr2, total_pattrns - 1);

	return total_pattrns - 1;
}

void PATTERNS::ChangePattern(std::string tempstr, int index)
{
	autofire_patterns[index].resize(tempstr.size());
	for (int i = tempstr.size() - 1; i >= 0; i--)
	{
		if (tempstr[i] == autofire_patterns_flagpress)
			autofire_patterns[index][i] = 1;
		else
			autofire_patterns[index][i] = 0;
	}
}

void PATTERNS::ChangeSequencePattern(int index, int on, int off)
{
	int size = on + off;
	autofire_patterns[index].resize(size);

	for (int i = size - 1; i >= 0; i--)
	{
		if (i < on)
			autofire_patterns[index][i] = 1;
		else
			autofire_patterns[index][i] = 0;
	}
}

void PATTERNS::ChangeIterativelyPattern(int index, int by, int size)
{
	int inc = 1;
	autofire_patterns[index].resize(size);

	for (int i = 0; i < size; i++)
	{
		if (i % inc == 0)
			inc += by * 2 - 1;
		if (i % inc < inc / 2)
			autofire_patterns[index][i] = 1;
		else
			autofire_patterns[index][i] = 0;
	}
}

int PATTERNS::MakeSequencePattern(int on, int off)
{
	std::string name = "Sequence Pattern - ";
	char nstr[21];
	int cur_pat = autofire_patterns.size() + 1;
	name += itoa(on, nstr, 10);
	name += "/";
	autofire_patterns_names.push_back(name + itoa(off, nstr, 10));
	autofire_patterns.resize(cur_pat);
	ChangeSequencePattern(cur_pat - 1, on, off);

	return cur_pat - 1;
}

int PATTERNS::MakeIterativelyPattern(int by, int size)
{
	std::string name = "Iterative Pattern: ";
	char nstr[21];
	int cur_pat = autofire_patterns.size() + 1;
	autofire_patterns_names.push_back(name + itoa(by, nstr, 10));
	autofire_patterns.resize(cur_pat);
	ChangeIterativelyPattern(cur_pat - 1, by, size);

	return cur_pat - 1;
}

bool PATTERNS::LoadPatterns()
{
//	InitPatterns();
	// load autofire_patterns
	char nameo[2048];
	strncpy(nameo, FCEU_GetPath(FCEUMKF_TASEDITOR).c_str(), 2047);
	strncat(nameo, patternsFilename, 2047 - strlen(nameo));
	EMUFILE_FILE ifs(nameo, "rb");
	if (!ifs.fail())
	{
		std::string tempstr1, tempstr2;
		while (ReadString(&ifs, tempstr1))
		{
			if (ReadString(&ifs, tempstr2))
			{
				MakePattern(tempstr1, tempstr2);
			}
		}
	} else
	{
		FCEU_printf("Could not load tools\\taseditor_patterns.txt!\n");
//		return false;
	}
	if (autofire_patterns.size() == 0)
	{
		DefaultPatterns();
	}
	
	// reset current_pattern if it's outside the range
	if (taseditor_config.current_pattern < 0 || taseditor_config.current_pattern >= (int)autofire_patterns.size())
		ResetPattern();

	taseditor_window.UpdatePatternsMenu();
	return true;
}

void PATTERNS::ResetPattern()
{
	taseditor_config.current_pattern = 0;	
}

void PATTERNS::DeletePattern()
{
	if(autofire_patterns.size() > 1)
	{
		autofire_patterns_names.erase(autofire_patterns_names.begin() + taseditor_config.current_pattern);
		autofire_patterns.erase(autofire_patterns.begin() + taseditor_config.current_pattern);
	}
	else MessageBox(hwndPatternEditor, "Cannot delete more patterns!", PATTERNS_MANAGERTITLE, MB_ICONERROR | MB_OK);
}

void PATTERNS::UpdateManager()
{
	for (int i = 0 ; i < autofire_patterns.size(); i++)
		SendMessage(hwndSelectPattern, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>((LPCTSTR)autofire_patterns_names[i].c_str()));

	SendMessage(hwndSelectPattern, CB_SETCURSEL, taseditor_config.current_pattern, 0);
}

void PATTERNS::UpdatePattern()
{
	char nstr[21];
	std::string name;
	if (sequentially)
	{
		name = "Sequence Pattern - ";
		name += itoa(sequence_on, nstr, 10);
		name += "/";
		autofire_patterns_names[taseditor_config.current_pattern] = name + itoa(sequence_off, nstr, 10);
		ChangeSequencePattern(taseditor_config.current_pattern, sequence_on, sequence_off);
	}
	if (iteratively)
	{
		name = "Iteratively Pattern - ";
		autofire_patterns_names[taseditor_config.current_pattern] = name + itoa(increase_by, nstr, 10);
		ChangeIterativelyPattern(taseditor_config.current_pattern, increase_by, max_size);
	}
	else
	{
		autofire_patterns_names[taseditor_config.current_pattern] = pattern_name;
		ChangePattern(fixed_pattern, taseditor_config.current_pattern);
	}
}

bool PATTERNS::VerifyValues()
{
	if (pattern_name.size() <= 0 || fixed_pattern.size() <= 0 || sequence_on <= 0 || sequence_off <= 0 || increase_by <= 0 || max_size <= 0)
	{
		DefaultSettings();
		MessageBox(hwndPatternEditor, "Cannot make pattern with no name, no value or without pattern!", PATTERNS_EDITORTITLE, MB_ICONWARNING | MB_OK);
		Reinitialization();
		return false;
	}
	else return true;
}

bool PATTERNS::ReadString(EMUFILE *is, std::string& dest)
{
	dest.resize(0);
	int charr;
	while (true)
	{
		charr = is->fgetc();
		if (charr < 0) break;
		if (charr == 10 || charr == 13)		// end of line
		{
			if (dest.size())
				break;		// already collected at least one char
			else
				continue;	// skip the char and continue searching
		} else
		{
			dest.push_back(charr);
		}
	}
	return dest.size() != 0;
}


int PATTERNS::GetCurrentPattern()
{
	return SendMessage(hwndSelectPattern, CB_GETCURSEL, 0, 0);					
}

void PATTERNS::DefaultPatterns()
{
	FCEU_printf("Will be using default set of patterns...\n");
	autofire_patterns.resize(4);
	autofire_patterns_names.resize(4);
	// Default Pattern 0: Alternating (1010...)
	autofire_patterns_names[0] = "Alternating (1010...)";
	autofire_patterns[0].resize(2);
	autofire_patterns[0][0] = 1;
	autofire_patterns[0][1] = 0;
	// Default Pattern 1: Alternating at 30FPS (11001100...)
	autofire_patterns_names[1] = "Alternating at 30FPS (11001100...)";
	autofire_patterns[1].resize(4);
	autofire_patterns[1][0] = 1;
	autofire_patterns[1][1] = 1;
	autofire_patterns[1][2] = 0;
	autofire_patterns[1][3] = 0;
	// Default Pattern 2: One Quarter (10001000...)
	autofire_patterns_names[2] = "One Quarter (10001000...)";
	autofire_patterns[2].resize(4);
	autofire_patterns[2][0] = 1;
	autofire_patterns[2][1] = 0;
	autofire_patterns[2][2] = 0;
	autofire_patterns[2][3] = 0;
	// Default Pattern 3: Tap'n'Hold (1011111111111111111111111111111111111...)
	autofire_patterns_names[3] = "Tap'n'Hold (101111111...)";
	autofire_patterns[3].resize(1000);
	autofire_patterns[3][0] = 1;
	autofire_patterns[3][1] = 0;
	for (int i = 2; i < 1000; ++i)
		autofire_patterns[3][i] = 1;
}

void PATTERNS::update()
{
	if (must_update)
	{
		if(!iteratively && !sequentially && !custom)
			CheckDlgButton(hwndPatternEditor,IDC_PATTERNS_SEQUENCE,BST_CHECKED);

		//GWTL gets wrong values!
		pattern_name = new char[GetWindowTextLength(hwndPatternName)];
		fixed_pattern = new char[GetWindowTextLength(hwndCurrentPattern)];

		SendDlgItemMessage(hwndPatternEditor,IDC_PATTERNS_SEQUENCE,BM_SETCHECK,sequentially?BST_CHECKED:BST_UNCHECKED,0);
		SendDlgItemMessage(hwndPatternEditor,IDC_PATTERNS_CUSTOM,BM_SETCHECK,custom?BST_CHECKED:BST_UNCHECKED,0);
		UpdateEnabledItems();
		sequence_on = GetDlgItemInt(hwndPatternEditor,IDC_PATTERNS_ON,0,0);
		sequence_off = GetDlgItemInt(hwndPatternEditor,IDC_PATTERNS_OFF,0,0);
		GetDlgItemText(hwndPatternEditor,IDC_PATTERNS_NAME,(LPSTR)pattern_name.c_str(),PATTERNS_NAME_TEXTLIMIT);
		GetDlgItemText(hwndPatternEditor,IDC_PATTERNS_CURRENT,(LPSTR)fixed_pattern.c_str(),PATTERNS_CURRENT_TEXTLIMIT);

		//by GWTL & GDIT (does not change the size of) strings need size fixing!
		pattern_name = FixLength(pattern_name);
		fixed_pattern = FixLength(fixed_pattern);

//		if (pattern_name == "")
//		{
//			pattern_name = SendDlgItemMessage(hDlg,IDC_PATTERNS_SETPATTERN,CB_GETCURSEL,0,(LPARAM)(LPSTR)0);
//			fixed_pattern = //TODO! CharTabToStr -> autofire_patterns[SendDlgItemMessage(hDlg,IDC_PATTERNS_SETPATTERN,CB_GETTOPINDEX,0,0)]
//		}

		must_update = false;
	}
}

std::string PATTERNS::FixLength(std::string str)
{
	std::string tmpstr;
	for (int i = 0; i < str.size(); i++)
		if (i > 0 && str[i] == 0)
		{
			str.resize(i);
			tmpstr = str;
			break;
		}
	return tmpstr;
}

void PATTERNS::SetCustomPattern()
{
	sequentially = false;
	custom = true;
	iteratively = false;
	reset();
}

void PATTERNS::SetIncreasingPattern()
{
	sequentially = false;
	custom = false;
	iteratively = true;
	reset();
}

void PATTERNS::SetSequencePattern()
{
	sequentially = true;
	custom = false;
	iteratively = false;
	reset();
}

void PATTERNS::CheckTypeOf()
{
	if(sequentially)
	{
		//in theory it is not necessary
		if (sequence_on >= 1000)
			sequence_on = 1000;
		
		if (sequence_off >= 1000)
			sequence_off = 1000;
		
		//it should work like SetAutoFirePattern(sequence_on, sequence_off) function
		taseditor_config.current_pattern = MakeSequencePattern(sequence_on, sequence_off);
	}
	if (iteratively)
	{
		taseditor_config.current_pattern = MakeIterativelyPattern(increase_by, max_size);
	}
	else
	{
		taseditor_config.current_pattern = MakePattern(pattern_name, fixed_pattern);
	}

	
//	taseditor_window.UpdatePatternsMenu();
//	ExitPatternEditor();
}

BOOL CALLBACK PatternEditorProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
//		case WM_INITDIALOG:
//			patterns.init();
//			return TRUE;
//			break;

		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDOK:
					patterns.reset();
					if (patterns.VerifyValues())
					{
						patterns.CheckTypeOf();
						patterns.isChanged = true;
						ExitPatternEditor();
					}
					break;

				case IDC_PATTERNS_SEQUENCE:
					patterns.SetSequencePattern();
					break;

				case IDC_PATTERNS_ITERATIVELY:
					patterns.SetIncreasingPattern();
					break;

				case IDC_PATTERNS_CUSTOM:
					patterns.SetCustomPattern();
					break;
				
				case IDCANCEL:
					ExitPatternEditor();
					break;

				//for testing!
//				case IDC_PATTERNS_OFF:
//				case IDC_PATTERNS_CURRENT:
//				case IDC_PATTERNS_ON:
//				case IDC_PATTERNS_NAME:
//					switch (HIWORD(wParam))
//					{
//						case EN_CHANGE:
//							patterns.isChanged = true;
//							break;
//					}
//					break;
			}
			break;

		case WM_CLOSE:
		case WM_QUIT:
			ExitPatternEditor();
			break;

//		case WM_DESTROY:
//			patterns.quit();
//			ExitPatternEditor();
//			break;
	}

	return FALSE;
}

bool PATTERNS::OpenPatternManager()
{
	bool temp;
	if ( temp = ShowWindow(hwndPatternManager, SW_SHOWNORMAL))
		SetActiveWindow(hwndPatternManager);
	return temp;
}

bool PATTERNS::OpenPatternEditor()
{
	bool temp;
	if ( temp = ShowWindow(hwndPatternEditor, SW_NORMAL))
	{
		SetActiveWindow(hwndPatternEditor);
		EnableWindow(hwndPatternManager, false);

		if (patOper == EDIT_CURRENT)
		{
			fixed_pattern = PatternToString(autofire_patterns[taseditor_config.current_pattern]);
			pattern_name = autofire_patterns_names[taseditor_config.current_pattern];
			update();
		}
		else Reinitialization();
	}
	return temp;
}

void ExitPatternManager()
{
	if (ShowWindow(patterns.hwndPatternManager, SW_HIDE))
		taseditor_window.UpdatePatternsMenu();
}

void PATTERNS::EditPattern()
{
	patOper = EDIT_CURRENT;
	SetWindowText(hwndPatternEditor,  (std::string(PATTERNS_EDITORTITLE) + std::string(" (New pattern)")).c_str());
	OpenPatternEditor();
}

void PATTERNS::NewPattern()
{
	patOper = MAKE_NEW;
	SetWindowText(hwndPatternEditor, (std::string(PATTERNS_EDITORTITLE) + std::string(" (Edit pattern)")).c_str());
	OpenPatternEditor();
}

void PATTERNS::Reload()
{
	InitPatterns();
	ResetPattern();
	isChanged = false;
	UpdateManager();
//	update();
	taseditor_window.UpdatePatternsMenu();
}

void PATTERNS::RemovePattern()
{
	DeletePattern();
	ResetPattern();
	isChanged = true;
	UpdateManager();
//	reset();
//	taseditor_window.UpdatePatternsMenu();
}

void PATTERNS::SetDefaultPatterns()
{
	if (AskDefaultPatterns())
	{
		DefaultPatterns();
		ResetPattern();
		isChanged = false;
		UpdateManager();
//		reset();
		taseditor_window.UpdatePatternsMenu();					
	}
}

BOOL CALLBACK PatternManagerProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
//		case WM_INITDIALOG:
//			patterns.init();
//			return TRUE;
//			break;

		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDOK:
					ExitPatternManager();
					break;

				case ID_PATTERNS_DEFAULT:
					patterns.SetDefaultPatterns();
					break;
				
				case ID_PATTERNS_RESET:
					patterns.Reload();
					break;

				case ID_PATTERNS_DELETE:
					patterns.RemovePattern();
					break;

				case ID_PATTERNS_EDIT:
					patterns.EditPattern();
					break;

				case ID_PATTERNS_NEW:
					patterns.NewPattern();
					break;

				case IDC_PATTERNS_SELECTPATTERN:
					switch(HIWORD(wParam))
					{
						case CBN_SELCHANGE:
							taseditor_config.current_pattern = patterns.GetCurrentPattern();
							break;
					}
					break;

				case ID_PATTERNS_SAVE:
					patterns.SavePatterns();
					break;
				
				case IDCANCEL:
					ExitPatternManager();
					break;
			}
			break;

		case WM_CLOSE:
		case WM_QUIT:
			ExitPatternManager();
			break;

//		case WM_DESTROY:
//			patterns.quit();
//			ExitPatternEditor();
//			break;
	}

	return FALSE;
}
