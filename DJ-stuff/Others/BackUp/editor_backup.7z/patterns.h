#define PATTERNS_CURRENT_TEXTLIMIT 1000
#define PATTERNS_NAME_TEXTLIMIT 512
#define PATTERNS_MAXINT_TEXTLIMIT 3
#define PATTERNS_EDITORTITLE "Pattern Editor"
#define PATTERNS_MANAGERTITLE "Pattern Manager"
#define PATTERNS_ADDFORMATINFO "FORMAT OF THIS FILE: 2 lines per every Pattern - first line is the name, second line is looped sequence of presses: 1 = press button, 0 = don't press button."
#define PATTERNS_ENTERSTR "\r\n"

enum
{
	MAKE_NEW,
	EDIT_CURRENT
};

class PATTERNS
{
public:
	PATTERNS();
	void init();
	void free();
	void reset();
	void update();
	void quit();

	HWND hwndPatternEditor;
	HWND hwndPatternManager;
	WORD IDD_PATTERN_MANAGER;

	std::vector<std::string> autofire_patterns_names;
	std::vector<std::vector<uint8>> autofire_patterns;

	void InitPatterns();
	void UpdateEnabledItems();

	int MakePattern(std::string tmpstr1, std::string tmpstr2);
	int MakeSequencePattern(int on, int off);
	int MakeIterativelyPattern(int by, int size);

	bool LoadPatterns();
	bool SavePatterns();

	void DefaultPatterns();
	void ResetPattern();
	void DeletePattern();
	void UpdatePattern();

	void UpdateManager();
	int GetCurrentPattern();

	bool VerifyValues();

	void CheckTypeOf();
	bool InputColumnSetPattern(int joy, int button);
	void InputSetPattern(int start, int end, int joy, int button, int consecutive_tag);
	bool FrameColumnSetPattern();

//	void UpdatePatternsMenu();
//	void RecheckPatternsMenu();

	bool OpenPatternManager();
	bool OpenPatternEditor();

	void Reload();
	void EditPattern();
	void NewPattern();
	void RemovePattern();
	void SetDefaultPatterns();

	void PATTERNS::SetCustomPattern();
	void PATTERNS::SetIncreasingPattern();
	void PATTERNS::SetSequencePattern();

	bool must_update, isChanged, sequentially, iteratively, custom;

private:
	void DefaultSettings();
	void Reinitialization();

	void ChangePattern(std::string tempstr, int index);
	void ChangeSequencePattern(int index, int on, int off);
	void ChangeIterativelyPattern(int index, int by, int size);

	bool ReadString(EMUFILE *is, std::string& dest);
	std::string FixLength(std::string str);
//	LPSTR PatternToString(std::vector<u8,std::allocator<u8>> pat);
	std::string PatternToString(std::vector<u8,std::allocator<u8>> pat);

	int sequence_on, sequence_off, increase_by, max_size;
//	bool model, sequentially, iteratively;
	std::string pattern_name, fixed_pattern;

	HWND hwndPatternName, hwndCurrentPattern, hwndSequenceON, hwndSequenceOFF, hwndSelectPattern, hwndMaxSize, hwndIncreaseBy;

	int patOper;
};