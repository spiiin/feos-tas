--[[
	pcsxrrWorkflowConfig.lua is part of the "PcsxrrEncodeWofkflow Project"
	http://tasvideos.org/Feos/PCSXResync.html
	Authors: badpotato, feos
--]]

module("pcsxrrWorkflowConfig",package.seeall)
package.cpath = package.cpath..";./dll/?.dll;./?.dll;./?.so;../lib/?.so;../lib/vc_dll/?.dll;../lib/bcc_dll/?.dll;../lib/mingw_dll/?.dll;../lua/?.dll;"

require "lfs"
require 'luaxml'
require "winapi"
--require "gd"
--require "profiler"
--require "socket"
--require "lanes"
--profiler.start("test.out")
--local linda= lanes.linda();

function setting()
	emu = pcsx;
	checkPoint = {}
	possibleDesync = {}
	fixedDesync = {}
	config = pcsxrrWorkflowConfig;
	currentPath = lfs.currentdir();
	im = nil; --special lib if we openGL2 for screenshot.
	getScreenShot = nil; --also used for the screenshot as a function pointer
	--Set to true only in "capture mode", while using kkapture
	encodeMode = false; --TODO: Should be an XML option
	--Set to true only in "capture mode", while using kkapture
	showEncodeErrorWarning = false;
	saveStateOffSet = 500;
	screenshotOffSet = 1;
	afterEndMovieStopOffset = 50; 
	startProcessFrame = 0; --need a xml option for this
	--Sadly we need to busy-wait at some point, because pcsxrr alway need to keep processing frame7
	--(or at some point pcsxrr will ask to kill the script)
	--busyWaitOffset = 30;
	--TODO: make some documentation about these value
	tolerateDesync = 3;
	untolerateDesync = 15;
	infoConfig = emu.getconfig();
	movieName = movie.name(); --movie.name() might crash the emu some time
	movieName = [[D:\SVN\feos-tas\pcsxrr\output\movies\BB2 slash mode 6443 dammit.pxm]];
	if(movie.mode() ~= nil or (movieName ~= nil and movieName ~= "")) then --if the mode is nil, this mean pcsxrr is still in bootup state
		movieName = movieName:match("[^\\]*$"); --get only the name.pxm of the movie, instead of the fullpath
	else
		moviePath = getStatusConfigInfo()["MoviePath"];
		if(moviePath ~= nil) then
			movieName = moviePath:match("[^\\]*.pxm$");
		else
			gui.popup("No movie detected, please select a movie:")
			moviePath = gui.filepicker("Please select a movie", "pxm");
			movieName = moviePath:match("[^\\]*.pxm$");
		end
	end
	--dofile("guiWorkflow.lua")
	movieSaveStateFolder = "sstates"
	configInfoFilePath = "workflowAppConfig.xml"
	pcsxrrEncodeWofkflowPath = "PcsxrrEncodeWofkflow";
	encodeWorkflowFolder = nil; -- now using a config xml for this	
	--TODO: Autoset according to the moviename
	if (encodeWorkflowFolder == nil and movieName ~= nil) then
		--encodeWorkflowFolder = pcsxrrEncodeWofkflowPath .. "/" .. movieName;
		encodeWorkflowFolder =  movieName;
	elseif (encodeWorkflowFolder == nil) then
		io.open(configInfoFilePath, "a+"):close(); --safe check
		encodeWorkflowFolder = getStatusConfigInfo()["WorkflowPath"];
	end
	if(encodeWorkflowFolder == nil) then
		gui.popup("Something failed while trying to load the workflow folder.")
	end
	detectInfoFilePath = encodeWorkflowFolder .. "/detectInfoStatus.xml"
	syncInfoFilePath = encodeWorkflowFolder .. "/syncInfoStatus.xml"
	saveStateFolder = encodeWorkflowFolder .. "/tasSoundSaveStates"
	desyncSaveStateFolder = encodeWorkflowFolder .. "/desyncSaveStates"
	--Made with the Eternal SPU plugin... sometime pcsxrr just need to reload a savestate for no reason to sync
	--Even if this is from the very same frame. This setting could be used to optimize the checkpoint list
	eternalSaveStateFolder = encodeWorkflowFolder .. "/eternalSaveStates"
	screenshotFolder = encodeWorkflowFolder .. "/screenshot"
	screenshotBackupFolder = screenshotFolder .. "/bak"
	imgScreenshotFolder = screenshotFolder .. "/img"
	hashFrameSplit = 200000;
	tokenMediatorFolder = encodeWorkflowFolder .. "/tokenMediator"
	--Might help in the boot up process so we just ignore possible desync in bootup process. Also this might help to avoid being lag framezoned
	firstLaglessFrameZone = nil;
	firstLaglessFrameZoneOffset = 50;
--[[
	snapshotName = nil;
	if(infoConfig["gpu"] == "gpuTASsoft.dll") then
		snapshotName = "snap_001.png";
		getScreenShot = gd.createFromPng;
	else
		--Why would you use the OpenGL GPU?
		--well, ok then...
		snapshotName = "PSOGL001.bmp";
		local imlua_open = package.loadlib("imlua51.dll", "imlua_open");
		im = imlua_open(); --load the imlua library
		getScreenShot = im.FileImageLoadBitmap;
	end	
	tempSnapshotName = "snap/___TEST.PNG";
	os.remove("snap/" .. snapshotName)
	os.remove(tempSnapshotName)
--]]
	saveStateName = "tasSaveState"
	desyncSaveStateName = "tasDesyncSaveState"
	--desyncLogFileName = "desyncLog"
	imgName = "detectScreenShot"
	hashFileName = "hashFrame"
	lastLaglessFrame = emu.framecount() -1;
	lastCheckPointScreenshotValue = "";
	lastCheckPoint = nil;
	createDir();
	frameHashedProcessed = getStatusDetectInfo()["CurrentScreenShotProcess"];
	checkPoint = loadCheckPoints();
	finalPass = getFinalPassToken();
end

function createDir()
	--First, let's make sure that the folder does exist
	lfs.mkdir(encodeWorkflowFolder)
	lfs.mkdir(screenshotFolder);
	lfs.mkdir(desyncSaveStateFolder);
	lfs.mkdir(tokenMediatorFolder);
	lfs.mkdir(imgScreenshotFolder);
	lfs.mkdir(saveStateFolder);
	--"touch" the status files)
	io.open(detectInfoFilePath, "a+"):close();
	io.open(syncInfoFilePath, "a+"):close();
	io.open(configInfoFilePath, "a+"):close();
end

--The GD library doesn't support BMP
--So we have to convert it by using the IM library.
function convertBmpToPNG(screen)	
	im.FileImageSave(tempSnapshotName, "PNG", screen);
	screen = gd.createFromPng(tempSnapshotName)
	os.remove(tempSnapshotName);
	return screen;
end
--[[
function getHashCode() 
	local waitCounter = 0;
	pcsx.makesnap();
	--pcsx.suspend(5);
	screen = getScreenShot("snap/" .. snapshotName )
	--screen = gd.createFromGdStr("snap/" .. snapshotName);
	while (screen == nil) do
		pcsx.testgpu();
		screen = getScreenShot("snap/" .. snapshotName )
		if (waitCounter % 10 == 0) then
			pcsx.makesnap();		
		elseif (waitCounter > 50) then
			print("Waiting for the gpu plugin to create the snap...")
			pcsx.suspend(50);
		elseif (waitCounter > 5) then
			pcsx.suspend(10);
		end
		waitCounter = waitCounter +1;
	end	
	if(snapshotName == "PSOGL001.bmp") then 
		--if using openGL2, we convert it to PNG.
		--TODO: find a better way to convert BMP as string
		screen = convertBmpToPNG(screen)
	end
	screen = screen:pngStr();	
	os.remove("snap/" .. snapshotName)
	return config.stringHash(screen);	
end

--return the hash value of a screen shot taken with the gd lib
function stringHash(textImg)		
	local counter = 1;
	local textLength = string.len(textImg); 
	mod=math.mod;  
	for i = 1, textLength, 3 do 
		counter = mod(counter*8161, 4294967279) + 
		(string.byte(textImg,i)*16776193) +
		((string.byte(textImg,i+1) or (textLength-i+256))*8372226) +
		((string.byte(textImg,i+2) or (textLength-i+256))*3932164);
	end; 
	return mod(counter, 4294967291); 
end
--]]
function getNearestCheckPoint(desyncFrame)
	checkPoint = getStatusDetectInfo()["CheckPoints"];
	previousCheckPoint = 0;
	for  k, checkPointFound in ipairs(checkPoint) do  
	--for checkPointFound in checkPoint do
		if((previousCheckPoint < desyncFrame and checkPointFound > desyncFrame) or previousCheckPoint == desyncFrame) then
			return previousCheckPoint;
		else
			previousCheckPoint = checkPointFound;
		end
	end
	return previousCheckPoint;
end

function writeStatusDetectInfo(state, currentFrame)
	root = xml.new("DetectStatus");
	root:append("MovieProcessed")[1] =  movieName;
	root:append("MovieDuration")[1] =  movieEnd;
	root:append("FirstLaglessFrameZone")[1] =  firstLaglessFrameZone;
	root:append("ScreenshotOffSet")[1] = screenshotOffSet;
	root:append("StateProcess")[1] = state;
	root:append("CurrentScreenShotProcess")[1] = currentFrame;
	if(#checkPoint == 0) then 
		checkPoint = loadCheckPoints();
	end
	checkPoints = root:append(xml.new("CheckPoints"));	
	checkPoint = table.unique(checkPoint);	
	table.sort(checkPoint)
	for k, v in ipairs(checkPoint) do
		checkPoints:append(tostring("_"..v));
	end
	fixedDesyncs = root:append(xml.new("FixedDesyncs"));	
	fixedDesync = table.unique(fixedDesync);	
	table.sort(fixedDesync)
	for k, v in ipairs(fixedDesync) do
		fixedDesyncs:append(tostring("_"..v));
	end
	root:save(detectInfoFilePath);
end

function getStatusDetectInfo()
	parseInfo = nil;
	statusDetectDocument = xml.load(detectInfoFilePath);
	if(statusDetectDocument ~= nil) then
		parseInfo = {
			["MovieProcessed"          ]=         statusDetectDocument:find("MovieProcessed"          ,nil,nil)[1] ,
			["MovieDuration"           ]=tonumber(statusDetectDocument:find("MovieDuration"           ,nil,nil)[1]),
			["FirstLaglessFrameZone"   ]=tonumber(statusDetectDocument:find("FirstLaglessFrameZone"   ,nil,nil)[1]),
			["ScreenshotOffSet"        ]=tonumber(statusDetectDocument:find("ScreenshotOffSet"        ,nil,nil)[1]),
			["StateProcess"            ]=         statusDetectDocument:find("StateProcess"            ,nil,nil)[1] ,
			["CurrentScreenShotProcess"]=tonumber(statusDetectDocument:find("CurrentScreenShotProcess",nil,nil)[1]),
		}
		if(#checkPoint == 0) then 
			checkPoint = loadCheckPoints();
		end
		statusCheckPoint = {};
		xmlCheckPoints = statusDetectDocument:find("CheckPoints", nil,nil);
		for i=1, #xmlCheckPoints do
			table.insert(statusCheckPoint,parseXmlNumberValue(statusDetectDocument:find("CheckPoints", nil,nil)[i][0]))
		end
		parseInfo["CheckPoints"]=statusCheckPoint;
		--merge the statusCheckPoint and checkPoint table together
		for k,v in pairs(statusCheckPoint) do checkPoint[k] = v end
		statusFixedDesync = {};
		xmlFixedDesync = statusDetectDocument:find("FixedDesyncs", nil,nil);
		for i=1, #xmlFixedDesync do
			table.insert(statusFixedDesync,parseXmlNumberValue(statusDetectDocument:find("FixedDesyncs", nil,nil)[i][0]))
		end
		parseInfo["FixedDesyncs"]=statusFixedDesync;
		fixedDesync = statusFixedDesync;
	else
		--print("No xml status found for the detection process.")
		parseInfo = {["CheckPoints"]={},["FixedDesyncs"]={},["CurrentScreenShotProcess"]=0};
	end

	return parseInfo;
end

function writeStatusSyncInfo(state, currentFrame)
	root = xml.new("SyncStatus");
	root:append("MovieProcessed")[1] =  movieName;
	root:append("MovieDuration")[1] =  movieEnd;
	--root:append("LastDesync")[1] = "000";
	root:append("CurrentFrame")[1] = currentFrame;
	root:append("StateProcess")[1] =  state;
	desyncLog = root:append(xml.new("PossibleDesyncs"));
	possibleDesync = table.unique(possibleDesync);	
	table.sort(possibleDesync)
	for k, v in ipairs(possibleDesync) do
		--The reason why we use "_" is because the normal XML standard
		--require absolutly that node name doesn't start by a number
		desyncLog:append(tostring("_"..v));
	end
	root:save(syncInfoFilePath);
end

function getStatusSyncInfo()
	parseInfo = nil;
	statusSyncDocument = xml.load(syncInfoFilePath);
	if(statusSyncDocument ~= nil) then
		parseInfo = {
			["MovieProcessed"]=statusSyncDocument:find("MovieProcessed",nil,nil)[1],
			["MovieDuration" ]=statusSyncDocument:find("MovieDuration" ,nil,nil)[1],
			["CurrentFrame"  ]=statusSyncDocument:find("CurrentFrame"  ,nil,nil)[1],
			["StateProcess"  ]=statusSyncDocument:find("StateProcess"  ,nil,nil)[1]
		}
		statusPossibleDesync = {};
		xmlPossibleDesyncs = statusSyncDocument:find("PossibleDesyncs", nil,nil);
		for i=1, #xmlPossibleDesyncs do
			table.insert(statusPossibleDesync,parseXmlNumberValue(statusSyncDocument:find("PossibleDesyncs", nil,nil)[i][0]))
		end
		parseInfo["PossibleDesyncs"]=statusPossibleDesync;
		possibleDesync = statusPossibleDesync;
	else
		--print("No xml status found for the synchronization process.")
		parseInfo = {["PossibleDesyncs"]={},["CurrentFrame"]=0};
	end
	return parseInfo;
end

function getStatusConfigInfo()
	parseInfo = nil;
	if(configInfoFilePath == nil) then
		return {};
	end
	statusConfigDocument = xml.load(configInfoFilePath);
	if(statusConfigDocument ~= nil) then
		parseInfo = {
			["PcsxrrPath"    ]=statusConfigDocument:find("PcsxrrPath"    ,nil,nil)[1],
			["MoviePath"     ]=statusConfigDocument:find("MoviePath"     ,nil,nil)[1],
			["TasSpuPath"    ]=statusConfigDocument:find("TasSpuPath"    ,nil,nil)[1],
			["EternalSpuPath"]=statusConfigDocument:find("EternalSpuPath",nil,nil)[1],
			["WorkflowPath"  ]=statusConfigDocument:find("WorkflowPath"  ,nil,nil)[1],
			["LuaScriptPath" ]=statusConfigDocument:find("LuaScriptPath" ,nil,nil)[1],
			["KkapturePath"  ]=statusConfigDocument:find("KkapturePath"  ,nil,nil)[1]
		}
	else
		parseInfo = {};
	end
	return parseInfo;
end

function parseXmlNumberValue(xmlNumber)
	if(xmlNumber:len() > 1) then
		xmlNumber = tonumber(xmlNumber:sub(2));
	end
	return xmlNumber;
end

--possible string(mode frame): 
--"desyncFound 122433"
--"desyncFixed 122422"
function parseClipboardString()
	local clipboardString = winapi.get_clipboard();
	if(clipboardString == nil) then return nil end
	local mode = clipboardString:match("%a*")
	local frame = clipboardString:match("[^%a%s]%d*")
	if(frame ~= "" and (mode == "desyncFound" or mode == "desyncFixed")) then 
		return {["mode"]=mode, ["frame"]=tonumber(frame)}
	else
		return nil;
	end
end

--set to the clipboard
function setClipboardString(mode, frame)
	winapi.set_clipboard(mode .. " " .. frame);
end

--get the last token
function getToken()
	local token = nil;
	for file in lfs.dir(tokenMediatorFolder) do
		if lfs.attributes(file,"mode") ~= "directory" then
			token = file;
			--os.remove(tokenMediatorFolder .. "/" .. file);
			local mode = file:match("%a*")
			local frame = file:match("[^%a%s]%d*")
			return {["mode"]=mode, ["frame"]=tonumber(frame)}
		end
	end
end

--set the token
function setToken(mode, frame)	
	cleanToken();
	io.open(tokenMediatorFolder .. "\\" .. mode .. " " .. frame, "a+"):close();
end

function cleanToken()
	for file in lfs.dir(tokenMediatorFolder) do
		if lfs.attributes(file,"mode") ~= "directory" then
			filename = tokenMediatorFolder .. "/" .. file
			os.remove(filename);
		end
	end
end

--set the token
function getFinalPassToken()	
	if(isFileExist(encodeWorkflowFolder .. "/" .. "activeFinalPass")) then
		return true;
	end
end
--set the token
function setFinalPassToken()	
	io.open(encodeWorkflowFolder .. "/" .. "activeFinalPass", "a+"):close();
end

--change the windows registry key for the pcsxrr spu plugin
function changeSpuRegKey(stringValue)	
	k,err = winapi.open_reg_key([[HKEY_CURRENT_USER\Software\PCSX-RR]], true)
	if not k then 
		return print('bad key',err)  --pcsxrr never ever run on the host computer?
	end
    k:set_value("PluginSPU",stringValue, winapi.REG_SZ);
	--print(k:get_value("PluginSPU"))
	k:close()
end

--load the list of checkpoint from the saveStateFolder
function loadCheckPoints()
	checkPoint = {}
	for file in lfs.dir(saveStateFolder) do 
		if lfs.attributes(file,"mode") ~= "directory" then 			
			table.insert(checkPoint,tonumber(file:sub(saveStateName:len()+2)))
		end
	end
	table.sort(checkPoint)
	table.unique(checkPoint)
	return checkPoint;
end

function loadScreenShotBackupFolder()
	local backupFolder = {}
	for file in lfs.dir(screenshotFolder) do 
		if lfs.attributes(file,"mode") == "directory" then 	
			print(file)		
			table.insert(backupFolder,file)
		end
	end
	table.sort(checkPoint)
	table.unique(checkPoint)
	return backupFolder;
end

function createSaveState(checkPointToCreate, isDesyncFix)
	--TODO: use new version!!
	if(checkPointToCreate == nil) then return end
	--fancy Ternary Operator in lua
	pathSaveState  = (
		(isDesyncFix==true) and
		(desyncSaveStateFolder .. "/" .. desyncSaveStateName) or
		(saveStateFolder .. "/" .. saveStateName)
	)
	if(savestate.savefile ~= nil) then
		savestate.savefile(pathSaveState .. "-" .. checkPointToCreate)
	else
		newStateFile = io.open(pathSaveState .. "-" .. checkPointToCreate, "wb");
		newCheckPoint = savestate.create(1);
		savestate.save(newCheckPoint)	;
		currentStateFile = io.open(movieSaveStateFolder .. "/" .. movieName .. ".000", "rb" );
		save = currentStateFile:read("*all");
		newStateFile:write(save);
		io.close(newStateFile);
		io.close(currentStateFile);
		print("Made a check point at " .. checkPointToCreate .. " using an old version.")
	end
	table.insert(checkPoint, emu.framecount()) --add the checkpoint to the checkpoint list
	table.sort(checkPoint)
end

--safe state loader, but might refresh the screen a bit late
function oldStateLoader(checkPointToLoad, isDesyncFix)
	if(checkPointToLoad == nil) then return end
	local pathSaveState  =	(
		(isDesyncFix==true) and
		(desyncSaveStateFolder .. "/" .. desyncSaveStateName) or
		(saveStateFolder .. "/" .. saveStateName)
	)
	if(isFileExist(pathSaveState .. "-" .. checkPointToLoad) == nil) then  --if nil look in the other directory
		testPathSaveState  = (
			(not isDesyncFix)==true	and
			(desyncSaveStateFolder .. "/" .. desyncSaveStateName) or
			(saveStateFolder .. "/" .. saveStateName)
		)
		if(isFileExist(testPathSaveState .. "-" .. checkPointToLoad) == nil) then
			print("File at \"" .. pathSaveState .. "-" .. checkPointToLoad .. "\" doesn't exist." )
			--TODO: Ask first detection script to create it?
			return;
		else
			pathSaveState = testPathSaveState;
		end
	end
	if(savestate.loadfile ~= nil) then
		savestate.loadfile(pathSaveState .. "-" .. checkPointToLoad);
		print("Loading checkpoint #" .. checkPointToLoad)
	else
		local saveStateFile = io.open(pathSaveState .. "-" .. checkPointToLoad, "rb")
		local save = saveStateFile:read("*all")
		local loadStateFile = io.open (movieSaveStateFolder .. "/" .. movieName .. ".000", "wb")
		loadStateFile:write(save)
		io.close(saveStateFile);
		io.close(loadStateFile) 
		local newCheckPoint = savestate.create(1)		
		savestate.load(newCheckPoint)
		print("Loading checkpoint #" .. checkPointToLoad .. "(with old version)")
	end
end
--[[--
--unsafe state loader, but will refresh the screen faster
function stateLoader(checkPointToLoad, isDesyncFix)
	if(checkPointToLoad ~= nil) then		
		newCheckPoint = savestate.create(3)	
		savestate.save(newCheckPoint)
		linda:set("finish", "start")
		linda:set("screenValue",  "start")
	 	lanes.gen("*",prepareScreen)(print, emu, gui, stringHash)
		redrawCheckpoint(checkPointToLoad, isDesyncFix); 
		emu.pause(); --pausing while kkapture still capture, might create some duplicate...
		screenVal = "start"
		while screenVal == "start" do
			screenVal=linda:receive(2.0,  "screenValue")
		end
		lastCheckPointScreenshotValue = screenVal;
		lastCheckPoint = emu.framecount();
		redrawCheckpoint(checkPointToLoad, isDesyncFix); 
		--print("Loading checkpoint #" .. checkPointToLoad)		
		print("Loading checkpoint #" .. emu.framecount())
	end
end

function prepareScreen(print, emu, gui, stringHash)
    for i=1,100 do
        linda:send( "x", i )    -- TODO some busy wait loop... might help for waiting time. Should be a better way to wait..
    end
	co2 = coroutine.create(
		function (x)
			emu.unpause();
			coroutine.yield()
		end
	)
	screenValue=stringHash(gui.gdscreenshot());
	linda:send( "screenValue", screenValue )
	coroutine.resume(co2)
end

local function waitingThread(maxWait, checkPointToLoad, print, emu, gui, saveStateFolder, saveStateName,movieSaveStateFolder,movieName, savestate, isDesyncFix, separateThreadLoadState, gen)
	for i=1,maxWait do
		linda:send( "x", i )    -- looping as a way to wait for the other thread to end...
	end
	gen("*",separateThreadLoadState)(checkPointToLoad, print, emu, gui, saveStateFolder, saveStateName,movieSaveStateFolder,movieName, savestate, isDesyncFix)
	finish = "start"
	linda:set( "finish", "start" )
	while finish =="start" do
		finish=linda:receive(2.0,  "finish")
	end
end

function separateThreadLoadState(checkPointToLoad, print, emu, gui, saveStateFolder, saveStateName, movieSaveStateFolder, movieName, savestate, isDesyncFix)
	newCheckPoint = nil;
	if(checkPointToLoad == "current") then
		newCheckPoint = savestate.create(3)	
		savestate.save(newCheckPoint)
	else 
		newCheckPoint = savestate.create(1)		
		pathSaveState  = (
			isDesyncFix==true and
			(desyncSaveStateFolder .. "/" .. desyncSaveStateName) or
			(saveStateFolder .. "/" .. saveStateName)
		)
		saveStateFile = io.open(pathSaveState .. "-" .. checkPointToLoad, "rb")
		save = saveStateFile:read("*all")
		loadStateFile = io.open (movieSaveStateFolder .. "/" .. movieName .. ".000", "wb")
		loadStateFile:write(save)
		io.close(loadStateFile) 
	end
	savestate.load(newCheckPoint)
	savestate.save(newCheckPoint) --save at slot1
	savestate.load(newCheckPoint)
	linda:send( "finish", "end" )   
end

function redrawCheckpoint(checkPointToLoad, isDesyncFix)
	--TODO: use some table instead of using so many params	lanes.gen("*",waitingThread)(100,checkPointToLoad,print,emu,gui,saveStateFolder,saveStateName,movieSaveStateFolder,movieName,savestate,isDesyncFix,separateThreadLoadState,lanes.gen)
end
--]]--
function printStack()
	print("-----------------------------")
	print(debug.traceback(coroutine.running(),"error at line : "))
	print("-----------------------------")
end

function isFileExist(path)
	local fileInfo = lfs.attributes(path)
	if fileInfo then
	    if fileInfo.mode == "directory" then
	        --print("Path points to a directory.")
	        return true;
	    elseif fileInfo.mode == "file" then
	        --print("Path points to a file.")
	        return true;
	    else
	        print("Path points to: "..fileInfo.mode)
	        return true;
	    end
	    --display(fileInfo) -- to see the detailed information
	else
		if(showEncodeErrorWarning) then
	    	print("The path is invalid (file/directory at \"" .. path .. "\" doesn't exist)") --TODO!!!
	    end
	    return nil;
	end
end

function table.contains(tbl, element)
	if(tbl == nil) then return false end
	for k, value in pairs(tbl) do
		if value == element then
			return true
		end
	end
	return false
end

function table.val_to_str(v)
  if "string" == type(v) then
    v = string.gsub(v, "\n", "\\n" )
    if string.match( string.gsub(v,"[^'\"]",""), '^"+$' ) then
      return "'" .. v .. "'"
    end
    return '"' .. string.gsub(v,'"', '\\"' ) .. '"'
  else
    return "table" == type(v) and table.tostring(v) or
      tostring(v)
  end
end

function table.key_to_str(k)
  if "string" == type(k) and string.match( k, "^[_%a][_%a%d]*$" ) then
    return k
  else
    return "[" .. table.val_to_str(k) .. "]"
  end
end

function table.tostring(tbl)
	--[[
  local result, done = {}, {}
  for k, v in ipairs(tbl) do
    table.insert( result, table.val_to_str(v))
    done[k] = true
  end
  for k, v in pairs(tbl) do
    if not done[k] then
      table.insert(result, table.key_to_str(k) .. "=" .. table.val_to_str(v))
    end
  end
  return "{" .. table.concat( result, "," ) .. "}"
  --]]
  tostring(tbl) --already in the global namespace of luaengine.cpp
end

-- Count the number of times a value occurs in a table 
function table.count(tbl, item)
	local count
	count = 0
	for ii,xx in pairs(tbl) do
		if item == xx then count = count + 1 end
	end
	return count
end

-- Remove duplicates from a table array (doesn't currently work
-- on key-value tables)
function table.unique(tbl)
	local newtable
	newtable = {}
	for ii,xx in ipairs(tbl) do
		if(table.count(newtable, xx) == 0) then
			newtable[#newtable+1] = xx
		end
	end
	return newtable
end

--require socket...
--benchmarking/metrics tools
function startBenchMark()
	--return socket.gettime()*1000;
end

--benchmarking/metrics tool
function stopBenchMark(startMetrics)
	--timeElapsed = socket.gettime()*1000 - startMetrics;
	return timeElapsed;
end