Written by Ilari.
Purpose: fix crackling sounds in Dolphin wav dumps.
Usage: "gapfix infile.wav outfile wav"
Note: compiled with 44-byte wav header in mind (that Dolphin uses).